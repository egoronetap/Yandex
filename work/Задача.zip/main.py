from flask import Flask

from data import db_session
from data.__all_models import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sfvasefaf'

db_session.global_init("db/users.db")
db_sess = db_session.create_session()
user = User()

user.surname = "Scott"
user.name = "Ridley"
user.age = 21
user.position = "captain"
user.speciality = "research engineer"
user.address = "module 1"
user.email = "scott_chief@mars.org"
db_sess.add(user)

user = User()
user.surname = "Biden"
user.name = "Joe"
user.age = 79
user.position = "president"
user.speciality = "main administrator"
user.address = "white house"
user.email = "joooo_biden@usmail.ru"
db_sess.add(user)

user = User()
user.surname = "Trump"
user.name = "Donald"
user.age = 75
user.position = "ex-president"
user.speciality = "administrator"
user.address = "USA"
user.email = "donald@usmail.ru"
db_sess.add(user)

user = User()
user.surname = "Obama"
user.name = "Barack"
user.age = 60
user.position = "ex-ex-president"
user.speciality = "low administrator"
user.address = "USA"
user.email = "obama@usmail.ru"


db_sess.add(user)
db_sess.commit()


# @app.route('/')
# def index():
#     db_sess = db_session.create_session()
#     user = db_sess.query(User).all()
